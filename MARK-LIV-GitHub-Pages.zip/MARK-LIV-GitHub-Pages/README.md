# MARK LIV — GitHub Pages Edition

A mobile-friendly browser interface inspired by the uploaded MARK LIV Python project.

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish. Open the URL shown in Settings → Pages.

## What this edition does
- Responsive MARK LIV-inspired HUD.
- Local browser chat demo with basic responses and arithmetic.
- Browser speech output using the device's built-in speech synthesis.
- Voice input where the browser supports Web Speech recognition.
- Quick links for web search, YouTube, and Gmail.
- Live local clock, browser/platform indicators, accent colors.

## Important limitations
This is a **static front-end website**, not the original Python desktop application. GitHub Pages cannot run Python desktop code or grant the site direct access to your computer. Therefore this version does not include real Gemini conversations, desktop/computer control, local file access, hardware telemetry, wake-word monitoring, or persistent AI memory. Those features require a separately hosted backend or a native desktop app. Never put an AI API key in `index.html` or any public repository.

Voice recognition support varies by browser and may require HTTPS (GitHub Pages provides HTTPS). On iPad, use Safari and allow microphone access if prompted.
