# MARK LIV — GitHub setup

This repository contains the original MARK LIV project files unpacked from the supplied single-file bundle.

## Upload to GitHub
1. Create a new **private** GitHub repository.
2. Extract this ZIP and upload the contents of this folder (not the ZIP itself).
3. Do not commit API keys, passwords, personal data, or generated memory files.

## Run locally
- Use a supported desktop computer (Windows, macOS, or Linux); this is a desktop Python app, not a GitHub Pages website.
- Install a compatible Python version, then run `python setup.py` from the repository folder.
- Follow the setup prompts and configure your Gemini API key in the app. Never paste the key into source code or commit it.
- Start the app with `python main.py`.

See `readme.md` for the project overview and original instructions. Some features depend on operating-system permissions, optional packages, API access, and local hardware.
